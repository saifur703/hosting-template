(function ($) {
    "use strict";

    jQuery(document).ready(function ($) {

        $(function () {
            $('.main-menu').slicknav();
        });


    });


    jQuery(window).on("load", function () {

    });



})(jQuery);